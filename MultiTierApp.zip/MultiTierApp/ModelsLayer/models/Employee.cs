﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLayer.models
{
   public class Employee
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Error in field !")]
        [MinLength(3,ErrorMessage ="name can't be less than 3 char !")]
        public string First_Name { get; set; }
        [Required]
        public string Last_Name { get; set; }
        [Required]
        [EmailAddress(ErrorMessage ="Email address i not valid")]
        public string Email { get; set; }
        [Required]

        [RegularExpression(pattern:@"^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$", ErrorMessage ="mobile number is not valid !")]
        public string Mobile { get; set; }
        public string OrgId { get; set; }    
        public int IsActive { get; set; }
    }
}
