﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLayer;
using ModelsLayer.models;

namespace MultiTierApp.Controllers
{
    public class EmployeesController : Controller
    {
        // GET: Employees

        private EmployeeBusiness employee;
        public EmployeesController()
        {
            employee = new EmployeeBusiness();
        }
        public ActionResult Index()
        {
            var emps = employee.GetEmployees();
            return View(emps);
        }
        public ActionResult Create()
        {
            
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            if (ModelState.IsValid)
            {
                int exist, created;
                string orgid;
                employee.CreateEmployee(emp, out exist, out created, out orgid);
                if (created == 1)
                {
                    ViewBag.msg = "Employee created with " + orgid + " Employee Id !";
                    return View(emp);
                }
                else if (exist == 1)
                {
                    ViewBag.msg = "Employee Already registered  with given email !";
                    return View(emp);
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return View(emp);
            }
        }
    }
}