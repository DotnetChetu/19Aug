﻿using ModelsLayer.InterfaceContract;
using ModelsLayer.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace DataAccessLayer
{
  public  class EmployeeDataAcess:DbConnectionConfig, IEmployee
    {
        public EmployeeDataAcess() : base()
        {
            
            
        }

        public void CreateEmployee(Employee emp, out int exist, out int created, out string orgid)
        {
            using (SqlCommand cmd = new SqlCommand("create_employees", connection))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@first_name", emp.First_Name);
                cmd.Parameters.AddWithValue("@last_name", emp.Last_Name);
                cmd.Parameters.AddWithValue("@email", emp.Email);
                cmd.Parameters.AddWithValue("@mobile", emp.Mobile);
                cmd.Parameters.AddWithValue("@isactive", emp.IsActive);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                exist = (int)dr["exist"];
                created = (int)dr["created"];
                orgid = dr["orgid"].ToString();

            }
        }

        public List<Employee> GetEmployees()

        {
            try {
                using (SqlCommand cmd = new SqlCommand("get_employees"))
                {
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (connection.State == ConnectionState.Closed)
                        connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    List<Employee> employees = new List<Employee>();
                    while (dr.Read())
                    
{
                        Employee emp = new Employee();
                        emp.Id = (int)dr["id"];
                        emp.First_Name = dr["first_name"].ToString();
                        emp.Last_Name = dr["last_name"].ToString();
                        emp.Email = dr["email"].ToString();
                        emp.Mobile = dr["mobile"].ToString();   emp.OrgId = dr["emp_id"].ToString();
                        emp.IsActive = (int)dr["isactive"];

                        employees.Add(emp);

                    }
                    return employees;
                }
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


    }
}
