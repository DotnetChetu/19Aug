﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace DataAccessLayer
{
    public class DbConnectionConfig
    {
        protected SqlConnection connection;
        public DbConnectionConfig()
        {
            string con =ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
            connection = new SqlConnection(con);

        }
    }
}
