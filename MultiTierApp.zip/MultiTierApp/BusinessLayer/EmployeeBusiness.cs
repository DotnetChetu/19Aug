﻿using ModelsLayer.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Net.Mail;
using System.Net.Mime;
namespace BusinessLayer
{
    public class EmployeeBusiness
    {
        private EmployeeDataAcess dataAcess;
        public EmployeeBusiness()
        {
            dataAcess = new EmployeeDataAcess();
        }

        public List<Employee> GetEmployees()
        {
            return dataAcess.GetEmployees();
        }

        public void CreateEmployee(Employee emp, out int exist, out int created, out string orgid)
        {
            dataAcess.CreateEmployee(emp, out exist, out created, out orgid);
            if (created == 1)
            {
                string sub = "Employee Confirmation Email !";

                StringBuilder sb = new StringBuilder();
                sb.Append("<div><h4 style='color:green'>Dear " + emp.First_Name + "</h4>");
                sb.Append("<p style='color:orange'> Your account created successfully !<p>");
                sb.Append("<p> Your Employee Id Generated : " + orgid + "</p>");
                sb.Append("<p>Thanks for connecting to us </p></div>");

                SendEmail("demo3408@gmail.com",emp.Email,sub,sb.ToString());
            }

        }

        public void SendEmail(string from, string to, string subject,string message, string cc=null)
        {
            MailMessage mail = new MailMessage(from, to);
            mail.Subject = subject;
            mail.Body = message;
            mail.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            smtp.Credentials = new System.Net.NetworkCredential()
            {
                UserName="demo3408@gmail.com",
                Password="9958119950"
            };
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }
     }
}
